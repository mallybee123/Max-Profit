<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                <!-- panel head -->
                <div class="panel-heading">
                    <div class="panel-title"><i class="fa fa-send"></i> <strong><?php echo e($page_title); ?></strong></div>

                </div>

                <!-- panel body -->
                <div class="panel-body">
                    <div class="row">
                        <?php $__currentLoopData = $plan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-sm-4 text-center">
                                <div class="panel panel-primary panel-pricing">
                                    <div class="panel-heading">
                                        <h3 style="font-size: 28px;"><b><?php echo e($p->name); ?></b></h3>
                                    </div>
                                    <div style="font-size: 18px;padding: 18px;" class="panel-body text-center">
                                        <p><strong><?php echo e($p->minimum); ?> <?php echo e($basic->currency); ?> - <?php echo e($p->maximum); ?> <?php echo e($basic->currency); ?></strong></p>
                                    </div>
                                    <ul style='font-size: 15px;' class="list-group text-center bold">
                                        <li class="list-group-item"><i class="fa fa-check"></i> Commission - <?php echo e($p->percent); ?> <i class="fa fa-percent"></i> </li>
                                        <li class="list-group-item"><i class="fa fa-check"></i> Repeat - <?php echo e($p->time); ?> times </li>
                                        <li class="list-group-item"><i class="fa fa-check"></i> Compound - <span class="aaaa"><?php echo e($p->compound->name); ?></span></li>
                                    </ul>
                                    <div class="panel-footer" style="overflow: hidden">
                                        <div class="col-sm-12">
                                            <button type="button" class="btn btn-primary bold uppercase btn-block btn-icon icon-left delete_button"
                                                    data-toggle="modal" data-target="#DelModal"
                                                    data-id="<?php echo e($p->id); ?>">
                                                <i class="fa fa-send"></i> Invest Under This Package
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

            </div>
        </div>
    </div><!---ROW-->


    <div class="modal fade" id="DelModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title bold uppercase" id="myModalLabel"> <i class='fa fa-exclamation-triangle'></i> Confirmation..!</h4>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Invest this Package.?</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="<?php echo e(route('investment-post')); ?>" class="form-inline">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="id" class="abir_id" value="0">

                        <button type="button" class="btn btn-default bold uppercase" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-success bold uppercase"><i class="fa fa-check"></i> Yes Sure.</button>
                    </form>
                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function () {

            $(document).on("click", '.delete_button', function (e) {
                var id = $(this).data('id');
                $(".abir_id").val(id);
            });
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>