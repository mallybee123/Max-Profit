<?php $__env->startSection('style'); ?>
    <script type="text/javascript" src="<?php echo e(asset('assets/admin/js/nicEdit-latest.js')); ?>"></script>

    <script type="text/javascript">
        bkLib.onDomLoaded(function() { new nicEditor({fullPanel : true}).panelInstance('area1'); });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">

            <div class="portlet box blue">
                <div class="portlet-title">
                    <div class="caption">
                        <strong><i class="fa fa-envelope"></i> Send Mail to - <?php echo e($user->name); ?></strong>
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"> </a>
                        <a href="javascript:;" class="remove"> </a>
                    </div>
                </div>
                <div class="portlet-body">

                    <form action="<?php echo e(route('user-email-submit')); ?>" method="post">

                        <?php echo csrf_field(); ?>



                        <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">

                        <div class="row uppercase">

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="col-md-12"><strong>SUBJECT</strong></label>
                                    <div class="col-md-12">
                                        <input class="form-control input-lg" name="subject" placeholder="Email Subject"  type="text" required="">
                                    </div>
                                </div>
                            </div>

                        </div><!-- row -->

                        <br><br>

                        <div class="row uppercase">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="col-md-12"><strong>Message</strong> NB: EMAIL WILL SENT USING EMAIL TEMPLATE</label>
                                    <div class="col-md-12">
                                        <textarea name="message" rows="10" class="form-control" id="area1"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div><!-- row -->

                        <br><br>
                        <div class="row uppercase">
                            <div class="col-md-12">

                                <button type="submit" class="btn btn-success btn-lg btn-block"> <i class="fa fa-send"></i> Send Mail</button>

                            </div>
                        </div><!-- row -->

                    </form>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>