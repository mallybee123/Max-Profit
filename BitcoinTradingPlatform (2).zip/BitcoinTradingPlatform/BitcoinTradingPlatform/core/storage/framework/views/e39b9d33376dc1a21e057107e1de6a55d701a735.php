
<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12">


            <div class="portlet light bordered">
                <div class="portlet-title">
                    <div class="caption font-dark">
                    </div>
                    <div class="tools"> </div>
                </div>
                <div class="portlet-body">
                    <table class="table table-striped table-bordered table-hover" id="sample_1">

                        <thead>
                        <tr>
                            <th>ID#</th>
                            <th>Date</th>
                            <th>Transaction ID</th>
                            <th>Withdraw Method</th>
                            <th>Withdraw Amount</th>
                            <th>Status</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $i=0;?>
                        <?php $__currentLoopData = $log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++;?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e(date('d-F-Y h:i A',strtotime($p->created_at))); ?></td>
                                <td><?php echo e($p->transaction_id); ?></td>
                                <td><?php echo e($p->method->name); ?></td>
                                <td><?php echo e($p->amount); ?> - <?php echo e($basic->currency); ?></td>
                                <td>
                                    <?php if($p->status == 1 ): ?>
                                        <span class="label bold label-warning"><i class="fa fa-spinner"></i> Pending</span>
                                    <?php elseif($p->status == 2): ?>
                                        <span class="label bold label-success"><i class="fa fa-check"></i> Complete</span>
                                    <?php elseif($p->status == 3): ?>
                                        <span class="label bold label-danger"><i class="fa fa-times"></i> Refund</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div><!-- ROW-->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-fileinput.js')); ?>"></script>

    <?php if(session('message')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Success!", "<?php echo e(session('message')); ?>", "success");

            });

        </script>

    <?php endif; ?>



    <?php if(session('alert')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Sorry!", "<?php echo e(session('alert')); ?>", "error");

            });

        </script>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>